package com.cg.employeemanagement.entity;

import java.util.ArrayList;
import java.util.List;

import com.cg.employeemanagement.dto.Employee;
import com.cg.employeemanagement.dto.Login;



public class LoginDatabase {
	private static List<Login> loginDB=new ArrayList<Login>();
	static
	{
		loginDB.add(new Login("adarsha","admin","adarsha",1));
	    loginDB.add(new Login("NareshBabu","manager","NareshBabu",2));
	    loginDB.add(new Login("suresh","manager","suresh",3));
	    loginDB.add(new Login("chintu","employee","chintu",4));
	    loginDB.add(new Login("Sahil","manager","Sahil",5));
	    loginDB.add(new Login("priya","employee","priya",6));
	    
	}
	public static List<Login> getLoginDetails() {
		return loginDB;
	}
	public static void setLoginDB(List<Login> loginDB) {
		LoginDatabase.loginDB = loginDB;
	}
	
	public boolean addCredentials(Employee emp)
	{
		if(emp.getUserId()==emp.getManagerId())
		{
		loginDB.add(new Login(emp.getUserName()+String.valueOf(emp.getUserId()), "manager","CapgeminiManager", emp.getUserId()));
		}
		else
		{
			loginDB.add(new Login(emp.getUserName()+String.valueOf(emp.getUserId()), "employee","CapgeminiEmployee", emp.getUserId()));
		}
		return true;
	}
	
	public int getId(String userName)
	{
		for(Login l : loginDB)
		{
			if(l.getUserName().equals(userName)){
				return l.getEmpId();
			}
		}
		return 0;
	}
	
}
