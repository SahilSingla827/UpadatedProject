package com.cg.employeemanagement.services;

import java.time.LocalDate;
import java.util.List;

import com.cg.employeemanagement.dto.Employee;

public interface AdminService {
	public boolean addEmployee(Employee emp);
	public boolean deleteEmployeeById(int empId);
	public boolean modifyEmployeeName(int empId,String empName);
	public boolean modifyEmployeeSalary(int empId,float empSal);
	public boolean modifyEmployeeDepartmentId(int empId,int deptId);
	public boolean modifyEmployeeDOB(int empId,LocalDate dob);
	public boolean modifyEmployeeContactNumber(int empId,Long empContactNumber);
	public boolean modifyEmployeeManagerId(int empId,int empManagerId);
	public Employee searchEmployeeById(String empId);
	public List<Employee> searchEmployessByName(String name);
	public List<Employee> displayEmployees();
	public boolean isValidPhone(String phone,String phonePattern);
	public boolean isValidName(String name,String namePattern);
	public boolean isValidDate(LocalDate dob);
	public boolean isValidYear(String year,String yearPattern);
	public boolean isValidDay(int day,int month,int year);
	public boolean isValidMonth(int month);
	public boolean validatePassword(String newPassword,String passwordPattern);
	public boolean changeAccountPassword(String newPassword,String userName);
	public boolean checkOldPassword(String oldPassword,String userName);
}
/*Enter 1: to update name\n"
+"Enter 2: to update Salary\n"
+"Enter 3: to update Department id\n"
+"Enter 4: to update Date of Birth\n"
+"Enter 5: to update Contact Number\n"
+"Enter 6: to update Manager Id\n");*/