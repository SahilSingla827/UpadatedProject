package com.cg.employeemanagement.services;

import java.util.List;
import java.util.regex.Pattern;

import com.cg.employeemanagement.dao.ManagerDao;
import com.cg.employeemanagement.dao.ManagerDaoImpl;
import com.cg.employeemanagement.dto.Employee;
import com.cg.employeemanagement.dto.Leave;
import com.cg.employeemanagement.validations.Validation;





public class ManagerServiceImpl implements ManagerService{
	
	ManagerDao managerDao=new ManagerDaoImpl();
	Validation valid = new Validation();
	
	@Override
	public Employee searchEmployeeById(String empId) {
		boolean flag = valid.validateEmpId(empId);
		if(flag){
		int eId=Integer.parseInt(empId);
		return managerDao.searchEmployeeById(eId);
		}
		else{
			return new Employee(0);
		}
	}
	
	@Override
	public List<Employee> searchEmployeeByName(String name) {
		// TODO Auto-generated method stub
		return managerDao.searchEmployeeByName(name);
	}
	
	@Override
	public Employee displayOwnDetails(String userName) {
		// TODO Auto-generated method stub
		return managerDao.displayOwnDetials(userName);
	}

	@Override
	public List<Employee> displaySubEmployees(String userName) {
		// TODO Auto-generated method stub
		return managerDao.displaySubEmployees(userName);
	}
	
	@Override
	public List<Leave> showLeavesApplied(String userName) {
		// TODO Auto-generated method stub
		return managerDao.showLeavesApplied(userName);
	}
	
	@Override
	public boolean accept(int leaveId) {
		// TODO Auto-generated method stub
		return managerDao.accept(leaveId);
	}

	@Override
	public boolean reject(int leaveId,String reason) {
		// TODO Auto-generated method stub
		return managerDao.reject(leaveId,reason);
	}
	@Override
	public boolean changeAccountPassword(String newPassword,String userName)
	{
		return managerDao.changeAccountPassword(newPassword, userName);
	}

    public boolean checkOldPassword(String oldPassword,String userName)
    {
    	return managerDao.checkOldPassword(oldPassword,userName);
    }

    public boolean validatePassword(String newPassword,String passwordPattern)
    {
    	if(Pattern.matches(passwordPattern, newPassword))
    	{
    		return true;
    	}
    	else
    	{
    		return false;
    	}
    }

	


}
