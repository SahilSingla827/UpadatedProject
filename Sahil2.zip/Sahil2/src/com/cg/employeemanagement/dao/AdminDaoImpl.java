package com.cg.employeemanagement.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.cg.employeemanagement.dto.Employee;
import com.cg.employeemanagement.entity.EmployeeStaticDB;

public class AdminDaoImpl implements AdminDao{
	
	EmployeeStaticDB esdb=new EmployeeStaticDB();
	
	@Override
	public boolean addEmployee(Employee emp) {
		return esdb.addData(emp);
	}

	@Override
	public boolean deleteEmployeeById(int empId) {
		// Function should delete employee based on employee id
		boolean b=esdb.delete(empId);
		return b;
	}
	@Override
	public boolean modifyEmployeeName(int empId, String empName) {
		esdb.modifyEmployeeName(empId, empName);
		return true;
	}

	@Override
	public boolean modifyEmployeeSalary(int empId, float empSal) {
		esdb.modifyEmployeeSalary(empId, empSal);
		return true;
	}

	@Override
	public boolean modifyEmployeeDepartmentId(int empId, int deptId) {
		esdb.modifyEmployeeDepartmentId(empId, deptId);
		return true;
	}

	@Override
	public boolean modifyEmployeeDOB(int empId, LocalDate dob) {
		esdb.modifyEmployeeDOB(empId, dob);
		return true;
	}

	@Override
	public boolean modifyEmployeeContactNumber(int empId, Long empContactNumber) {
		esdb.modifyEmployeeContactNumber(empId, empContactNumber);
		return true;
	}

	@Override
	public boolean modifyEmployeeManagerId(int empId, int empManagerId) {
		esdb.modifyEmployeeManagerId(empId, empManagerId);
		return true;
	}

	@Override
	public Employee searchEmployeeById(int empId) {
		// the function should search for an employee based on the employee id.
		List<Employee> list = esdb.getEmployeeList();
		for(Employee e :list)
		{
			if(e.getUserId()==empId)
			{
				return e;
			}
		}
		return null;
	}

	@Override
	public List<Employee> searchEmployessByName(String name) {
		// the function should search for the employee name present and return all the emp details with matching employee name
		List<Employee> list = esdb.getEmployeeList();
		List<Employee> resultList=new ArrayList<Employee>();
		for(Employee e :list)
		{
			if(e.getUserName().equals(name))
			{
				resultList.add(e);
			}
		}
		return resultList;
	}
	
	@Override
	public List<Employee> displayEmployees() {
		// the function should return all the employee details present
		List<Employee> list = esdb.getEmployeeList();
		return list;
	}


	
	
}
